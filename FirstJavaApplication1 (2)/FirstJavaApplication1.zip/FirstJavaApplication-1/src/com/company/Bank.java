package com.company;

import java.util.ArrayList;
import java.util.List;

public class Bank implements IBank{

    protected List<IAccount> accountsList;
    protected double balance;
    private int accountNumber;
    private static int lastAccount = 0;


    public Bank(){
        balance = 0;
        accountNumber = lastAccount + 1;
        lastAccount = accountNumber;
        accountsList = new ArrayList<IAccount>();

    }
    @Override
    public void OpenAccount(IAccount account) {
        accountsList.add(account);


    }

    @Override
    public void CloseAccount(int accountNumber) {
        List <IAccount > iterator_list = new ArrayList<IAccount>();
        for (IAccount account:accountsList
             ) {
            if(account.GetAccountNumber() == accountNumber){
                if(account.GetCurrentBalance() >=0){
                   iterator_list.add(account);
                }
                else{
                    System.out.println("Pay us back pls");
                }
            }

        }
        this.accountsList.removeAll(iterator_list);

    }

    @Override
    public List<IAccount> GetAllAccounts() {
        return accountsList;
    }

    @Override
    public List<IAccount> GetAllAccountsInDebt() {
        List <IAccount> negatives = new ArrayList<IAccount>();
        for (IAccount account:accountsList
             ) {
            if(account.GetCurrentBalance() < 0){
                negatives.add(account);
            }

        }
        return negatives;
    }

    @Override
    public List<IAccount> GetAllAccountsWithBalance(double balanceAbove) {
        List <IAccount> biggerAccounts = new ArrayList<IAccount>();
        for (int i = 0 ; i<accountsList.size(); i++){
            if (accountsList.get(i).GetCurrentBalance() > balanceAbove){
                biggerAccounts.add(accountsList.get(i));
            }
        }
        return biggerAccounts;
    }
}
