package com.company;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
       // System.out.println("Howdy! - Change - Change 2 - Change 3");
        // Here I was trying to test if the Account class works
        List<IAccount> accounts = new ArrayList<IAccount>();
        accounts.add(new Basic(1, 100));
        accounts.add(new Basic(2,200));
        accounts.add(new Standard(2, -100));
        accounts.add(new Premium(3));
        accounts.add(new Basic(4,200));
        accounts.add(new Premium(5));
        accounts.add(new Standard(6, -1000));

        for (IAccount account:accounts) {
            account.Deposit(100);
            System.out.println("Withdraw 500, " + account.GetAccountNumber() + " can withdraw " + account.Withdraw(500));
            System.out.println("Withdraw 800, " +account.GetAccountNumber() + " can withdraw " + account.Withdraw(800));

        }

        //Here I am testing Bank

        Bank bank_accounts = new Bank();
        Account premium_account = new Premium(1);
        bank_accounts.OpenAccount(premium_account);
        Account basic_Account = new Basic(2, -100);
        bank_accounts.OpenAccount(basic_Account);

        System.out.println(bank_accounts.GetAllAccounts());
        //bank_accounts.CloseAccount(2);
       // System.out.println(bank_accounts.GetAllAccounts());




    }
}
