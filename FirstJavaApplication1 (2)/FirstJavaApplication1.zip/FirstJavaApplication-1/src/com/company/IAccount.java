package com.company;

public interface IAccount {
    void Deposit (double amount);
    double Withdraw(double amount);
    double GetCurrentBalance();
    int GetAccountNumber();
}
//in order to make the above work, I'm going to create a java file called "Account"