package com.company;

public class Account implements IAccount{ //this is in order to make this account be connected with the interface
//all of the below are protected which means that no one outside of this interface or class will be able to change it or use it
    protected int accountNumber; //int = integer
    protected double accountBalance; //double = not whole numbers like 0.83
    protected double creditLimit;
    protected double withdrawLimit;
//the above are meant for being about to return something



    public Account(int accountNumber, double creditLimit, double withdrawLimit) {
        this.accountNumber = accountNumber;
        this.creditLimit = creditLimit;
        this.withdrawLimit = withdrawLimit;
    }




    @Override
    public void Deposit(double amount) {
        accountBalance = accountBalance + amount; //because I'm depositing, it means that I'm increasing my balance which is why there is addition here
//I don't return here because of the void
    }

    @Override
    public double Withdraw(double amount) {

        return amount;
    }

    @Override
    public double GetCurrentBalance() {
        return this.accountBalance; //Once again, because of the keyword "current" I added "this"
    }

    @Override
    public int GetAccountNumber() {
        return this.accountNumber; //I added "this" because of the keyword "current"
    }
}
